Thanks for purchasing the codem blvck hud

- if the seatbelt doesn't work add this to server.cfg setr game_enableFlyThroughWindscreen true
- if you don't want to use the stress system check Config.UseStress
- you can change top right text from the Config.WaterMarkText1 and Config.WaterMarkText2

if you have any issues you can join our discord to get support  
https://discord.gg/zj3QsUfxWs